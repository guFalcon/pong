package sample;

import javafx.geometry.Point2D;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;

public class Paddle implements GameObject{
    private Point2D position = new Point2D(0, 0);
    private Line line = new Line(0, 0, 0, 60);

    @Override
    public void initialize(Pane pane) {
        pane.getChildren().add(line);
    }

    @Override
    public void update(float gameTime) {
        position = new Point2D(position.getX() + 1, position.getY());
    }

    @Override
    public void draw(float gameTime) {
        line.setTranslateX(position.getX());
        line.setTranslateY(position.getY());
    }
}
