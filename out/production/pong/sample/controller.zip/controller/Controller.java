package sample.controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.layout.StackPane;
import sample.Paddle;
import sample.PongGame;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    @FXML
    private Canvas canvas;
    @FXML
    private StackPane stackPane;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        stackPane.setStyle("-fx-background-color: #9a4e4e");

        PongGame game = new PongGame(stackPane);
        Paddle paddle1 = new Paddle();
        game.add(paddle1);
        Thread thread = new Thread(game);
        thread.start();
    }
}
