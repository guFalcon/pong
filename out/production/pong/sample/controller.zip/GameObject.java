package sample;

import javafx.scene.layout.Pane;

public interface GameObject {
    void initialize(Pane pane);
    void update(float gameTime);
    void draw(float gameTime);
}
